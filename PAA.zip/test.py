def produto(x, y):
    if(x == '0' or y == '0'): return '0'
    if(x=='1'): return y
    if(y=='1'): return x
    if('+' in y):
        strng = '+' + x
        strng = strng.join(y.split('+'))
        return x + strng

    return x + y

def soma(x, y):
    if(x=='0'): return y
    if(y=='0'): return x

    return x + '+' + y

def solucao(A, B, n):
    i, j, k = [0, 0, 0]
    vet = []
    Linhas = []
    for x in range(n):
        vet.append(chr(x + 97))
    while(i<n):
        Colunas = []
        while(j<n):
            somatorio = '0'
            while(k<n):
                p = produto(B[i][k], A[k][j])
                somatorio = soma(somatorio, p)
                k += 1
            k = 0
            somatorio = verificar(somatorio, vet[i], vet[j])
            Colunas.append(somatorio)
            j += 1
        j = 0
        Linhas.append(Colunas)
        i += 1

    return Linhas

def aplicacao(A, B, n):
    Result = solucao(A, B, n)
    for i in range(n-3):
        Result = solucao(Result, B, n)

    return Result

def verificar(strng, vet, vt):
    if(vet == vt): return '0'
    aux = strng.split('+')
    novo = ''
    for i in range(len(aux)):
        if(not(vet in aux[i] or vt in aux[i])):
            novo += aux[i]
            if(i < len(aux)-1): novo += '+'
    if(novo == ''): return '0'
    return novo

def organizar(M, n):
    for i in range(n):
        for j in range(n):
            if(M[i][j] != '0'):
                strng = M[i][j].split('+')
                M[i][j] = strng[0]
                for k in range(len(strng)-1):
                    if(len(strng[k+1]) == n-2): M[i][j] = soma(M[i][j], strng[k+1])
    
    return M

grafo = open('grafo2/grafo2.txt', 'r')
adj = open('grafo2/adjacencia.txt', 'r')
texto = []
matriz = []
mtrzAdj = []
texto = grafo.readlines()

for i in range(len(texto)):
    matriz.append(texto[i].split())

for i in range(len(texto)):
    print(matriz[i])  
print("")

texto = adj.readlines()

for i in range(len(texto)):
    mtrzAdj.append(texto[i].split())

for i in range(len(texto)):
    print(mtrzAdj[i])
print("")

result = aplicacao(mtrzAdj, matriz, len(texto))
result = organizar(result, len(result))
print("resultado:")
for i in range(len(texto)):
    print(result[i])
print("")

adj.close()
grafo.close()